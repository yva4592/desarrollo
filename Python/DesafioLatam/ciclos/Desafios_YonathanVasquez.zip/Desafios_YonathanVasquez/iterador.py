# -*- coding: utf-8 -*-
"""
Created on Tue May 18 18:30:18 2021

@author: YonathanVasquez
"""




"""
i = 0
while i < 50 :
    print( "Iteración {}" .format(i + 1 ))
    i += 1

"""


### Se reemplaza por el "for"

for i in range(50):
        print( "Iteración {}" .format(i + 1 ))