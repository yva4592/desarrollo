package Logica;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class ClsPersona {
   public int idpersona;
   public String apellidos;
   public String nombres;
   public String fechaNacimiento;
   public String sexo;
   public String EstadoCivil;
   //Constructor
   public ClsPersona(){
   }
   
   /**Lógica-Método para Registrar Persona*/
public boolean RegistrarPersona(){
     boolean respuesta=true;
     
    try {
         Datos.ClsPersona persona=new Datos.ClsPersona();
         persona.idpersona=this.idpersona;
         persona.apellidos=this.apellidos;
         persona.nombres=this.nombres;
         persona.fechaNacimiento=ConvertirFecha(this.fechaNacimiento);
         persona.EstadoCivil=this.EstadoCivil;
         persona.sexo=this.sexo;
        respuesta=persona.RegistrarPersona(); //ejecuta el método que registra persona
                 
    }catch(Exception ex){
        System.out.println("Se ha presentado el siguiente Error: "+ex);
    }

    return respuesta;
}
   /**Lógica-Método para Actualizar Persona*/
public boolean ActualizarPersona(){
     boolean respuesta=true;
     
    try {
         Datos.ClsPersona persona=new Datos.ClsPersona();
         persona.idpersona=this.idpersona;
         persona.apellidos=this.apellidos;
         persona.nombres=this.nombres;
         persona.fechaNacimiento=ConvertirFecha(this.fechaNacimiento);
         persona.EstadoCivil=this.EstadoCivil;
         persona.sexo=this.sexo;
        respuesta=persona.ActualizarPersona(); //ejecuta el método que actualiza persona
                 
    }catch(Exception ex){
        System.out.println("Se ha presentado el siguiente Error: "+ex);
    }

    return respuesta;
}

public boolean EliminarPersona(int idPersona){
     boolean respuesta=true;
     
    try {
         Datos.ClsPersona persona=new Datos.ClsPersona();
         respuesta=persona.EliminarPersona(idPersona); //ejecuta el método que elimina persona         
    }catch(Exception ex){
        System.out.println("Se ha presentado el siguiente Error: "+ex);
    }

    return respuesta;
}

/** Lógica-Convierte fecha de String a Date*/
    public Date ConvertirFecha(String Fecha){
    //System.out.println(Fecha);
    Date fechaDevolver=null;
    SimpleDateFormat FormatoFecha= new SimpleDateFormat("dd/MM/yyyy");
        try {
            fechaDevolver=(Date)FormatoFecha.parse(Fecha);
            //System.out.println(fechaDevolver);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    return fechaDevolver;
}
     /**Lógica- Listar Personas*/
       public TableModel ListarPersonas(){
        TableModel modelo = new DefaultTableModel();

        try {
                       Datos.ClsPersona persona=new Datos.ClsPersona();
                       modelo=persona.ListarPersonas();
            
        } catch(Exception ex) {
             System.out.println(ex);        
        }
        return modelo;
       }

      /**Lógica- Busca Personas*/
       public TableModel BusquedaPersonas(String ApellidosNombres){
        TableModel modelo = new DefaultTableModel();

        try {
                       Datos.ClsPersona persona=new Datos.ClsPersona();
                       modelo=persona.BusquedaPersonas(ApellidosNombres);
            
        } catch(Exception ex) {
             System.out.println(ex);        
        }
        return modelo;
       }
       
       public ComboBoxModel ListarEstadoCivil(){
                  ComboBoxModel modelo = new DefaultComboBoxModel();

        try {
                       Datos.ClsPersona persona=new Datos.ClsPersona();
                       modelo=persona.ListarEstadoCivil();
            
        } catch(Exception ex) {
             System.out.println(ex);        
        }
        return modelo;
       }
}
