
package Datos;
import java.sql.*;
public class conexion {
    private String driver="org.postgresql.Driver";
    private String connectString="jdbc:postgresql://127.0.0.1:5432/prueba";
    private String user="postgres";
    private String password="impacto";
    public Connection con;
    
    public conexion(){
        
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(connectString, user , password);
        }catch ( Exception e ){
            System.out.println("error: no se pudo conectar a la base de datos: "+e.getMessage());
        }
    }

}
