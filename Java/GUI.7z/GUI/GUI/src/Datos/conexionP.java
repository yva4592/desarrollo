
package Datos;
import java.sql.*;
public class conexionP {
    private String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private String connectString="jdbc:sqlserver://127.0.0.1:1433;databaseName=bdtienda";
    private String user="sa";
    private String password="";
    public Connection con;
   
    
    public conexionP(){
        
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(connectString,user,password);
        }catch ( Exception e ){
            System.out.println("error: no se pudo conectar a la base de datos: "+e.getMessage());
        }
    }

}
