/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.videotutorial.primera.modelo;



/**
 *
 * @author Yonathan
 */

public class DatosEncuesta {
    
    
    private String nombreCompleto;
    private String[] progLeng;
    
    
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String[] getProgLeng() {
        return progLeng;
    }

    public void setProgLeng(String[] progLeng) {
        this.progLeng = progLeng;
    }
    
}
