﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class Equipo
    {
        public string nombreEquipo { get; set; }
        public DateTime fechaCreacion { get; set; }
        public string localidad { get; set; }
    }
}
