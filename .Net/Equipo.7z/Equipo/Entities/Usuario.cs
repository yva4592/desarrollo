﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class Usuario
    {
        public int idUsuario { get; set; }
        public string tipo { get; set; }        
    }
}
