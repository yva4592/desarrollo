﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class Contrato
    {
        public int idJugador { get; set; }
        public string nombreEquipo { get; set; }
                
    }
}
