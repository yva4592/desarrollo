﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class FichaContrato
    {
       // public int id { get; set; }
        public int idJugador { get; set; }
        public string nombreEquipo { get; set; }
        public int pagoMensual { get; set; }
    }
}
