﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class Partido
    {
        public int idPartido { get; set; }
        public int idTorneo { get; set; }
        public string NombreLocal { get; set; }
        public string NombreVisita { get; set; }
        public int golesLocal { get; set; }
        public int golesVisita { get; set; }
        public DateTime fechaPartido { get; set; }
    }
}
