﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class Jugador
    {
        public int id{ get; set; }
        public int rut { get; set; }
        public string Nombre { get; set; }
        public string apellido{ get; set; }
    }
}
