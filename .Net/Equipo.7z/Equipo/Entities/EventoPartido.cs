﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class EventoPartido
    {
        public int idEvento { get; set; }
        public int idJugador { get; set; }
        public int idPartido { get; set; }
        public DateTime fechaEvento { get; set; }
        public string nota { get; set; }
    }
}
