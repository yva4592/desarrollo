﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BLL
{
    public class ValidationResultcs
    {
        public bool IsValid { get; set; }
        public List<string> Errors { get; set; }
        public string Mensaje { get; set; }

        public ValidationResultcs()
        {
            Errors = new List<string>();
            IsValid = true;
        }

        public void AgregarError(string msj)
        {
            IsValid = false;
            Errors.Add(msj);
        }
    }
}
