﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using Entities;

namespace BLL
{
    public class BackEndBLL
    {


        //public ValidationResultcs VerUsuario(Usuario usuario)
        //{
            
        //    ValidationResultcs r = new ValidationResultcs();
        //    if (usuario.idUsuario == null)
        //    {
        //        r.AgregarError("El usario debe tenr un id");
        //    }
        //    if (usuario.tipo =="")
        //    {
        //        r.AgregarError("El tipo es obligatorio");
        //    }

            

            

        //    if (r.IsValid)
        //    {
        //        using (var db = new UsuarioDAL())
        //        {
        //            db.Insertar(usuario);
        //            r.Mensaje = "el usuario de tipo: " + usuario.tipo + "ha ingresado";
        //        }
        //    }
        //    return r; 
        //}


    
    
    }
}
