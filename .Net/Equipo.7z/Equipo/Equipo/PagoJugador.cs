﻿using System;
using System.Windows.Forms;
using DAL;
using Entities;

namespace Equipo
{
    public partial class PagoJugador : Form
    {
        public PagoJugador()
        {
            InitializeComponent();
        }

        private void PagoJugador_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = new DAL.JugadorDAL().VerTodo();
            comboBox1.ValueMember = "rut";                        
        }

        private void button1_Click(object sender, EventArgs e)
        {

            var juga = new DAL.JugadorDAL().BuscarPorRut(int.Parse(comboBox1.Text));
            int id = juga.id;

            var a = new DAL.ContratoDAL().BuscarPorId(id);

            try
            {
                string nombreEquipo = a.nombreEquipo;
                int idjugador = a.idJugador;

                var verrr = new DAL.FicharJugadorDAL().BuscarPorIdyNombre(idjugador, nombreEquipo);
                int? pagoMensual = verrr.pagoMensual;

                var part = new DAL.PartidoDAL().BuscarPorNombreEquipo(nombreEquipo);
                int idTorneo = part.idTorneo;

                var tor = new DAL.TorneoDAL().BuscarPorIdTorneo(idTorneo);
                DateTime fi = tor.fechaInicio;
                DateTime ft = tor.fechaTermino;

                TimeSpan cantidadDias = ft - fi;

                int dia = cantidadDias.Days;

                int meses = dia / 30;

                label1.Text = Convert.ToString(meses * pagoMensual);


            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Jugador no tiene Equipo");
            }


            
            
            

        }
    }
}
