﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Equipo
{
    public partial class BackEnd : Form
    {
        public BackEnd()
        {
            InitializeComponent();
        }

        private void crearToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new CrearTorneo().Show();
        }

        private void crearToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            new CrearEquipo().Show();
        }

        private void pagoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new PagoEquipo().Show();
        }

        private void crearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CrearJugador().Show();
        }

        private void crearToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            new CrearContrato().Show();
        }

        private void pagoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new PagoJugador().Show();
        }

        private void fichaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FichaJugador().Show();
        }

        private void crearToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            new CrearPartido().Show();
        }

        private void traspasoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
