﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Entities;
using DAL.DsEquipoTableAdapters;
using DAL;

using BLL;

namespace Equipo
{
    public partial class Inicio : Form
    {
       

        public Inicio()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = 0;
            string tipo = "";

            try
            {
                //  Entities.Usuario usu = new Entities.Usuario
                //  {
                //     idUsuario= int.Parse(textBox1.Text),
                //     tipo = textBox2.Text
                //  };
                //var ve2 = new BLL.BackEndBLL().VerUsuario(usu);
                //foreach (Usuario us in ve2)
                //{
                //    id = us.idUsuario;
                //    tipo = us.tipo;
                //}

                var ve = new DAL.UsuarioDAL().verPorIDyTipo(int.Parse(textBox1.Text), textBox2.Text);
                foreach (Usuario u in ve)
                {
                    id = u.idUsuario;
                    tipo = u.tipo;
                }


                if (tipo == "live" && id == int.Parse(textBox1.Text))
                {
                    new BackEnd().Show();
                    new Live().Show();
                }
                else
                    if (tipo == "Admin" && id == int.Parse(textBox1.Text))
                    {
                        new BackEnd().Show();
                    }
                    else
                    {
                        MessageBox.Show("Usuario no existe");
                    }
           
            }
            catch (Exception)
            {
                MessageBox.Show("debe ingresar el tipo de usuario");
            }
        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 5000;
            timer1.Start();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar) < 48 && e.KeyChar != 8) || e.KeyChar > 57)
            {
                MessageBox.Show("Solo Nùmeros");
                e.Handled = true;
            }
        }

        private void verResultadosDeLosPartidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Publico().Show();


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            notifyIcon1.ShowBalloonTip
              (2000, "Vistas de partidos", "ver paritdos",
              ToolTipIcon.Info);
        }

        private void notifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {
            new Publico().Show();
        }

        
    }
}
