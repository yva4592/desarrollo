﻿namespace Equipo
{
    partial class Publico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelE1 = new System.Windows.Forms.Label();
            this.labelE_2 = new System.Windows.Forms.Label();
            this.gol1 = new System.Windows.Forms.Label();
            this.gol2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.c = new System.Windows.Forms.Label();
            this.label_milisegundos = new System.Windows.Forms.Label();
            this.label_segundos = new System.Windows.Forms.Label();
            this.b = new System.Windows.Forms.Label();
            this.label_minutos = new System.Windows.Forms.Label();
            this.a = new System.Windows.Forms.Label();
            this.label_hora = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.SuspendLayout();
            // 
            // labelE1
            // 
            this.labelE1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelE1.Location = new System.Drawing.Point(157, 116);
            this.labelE1.Name = "labelE1";
            this.labelE1.Size = new System.Drawing.Size(123, 36);
            this.labelE1.TabIndex = 0;
            this.labelE1.Text = "Equipo_1";
            // 
            // labelE_2
            // 
            this.labelE_2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelE_2.Location = new System.Drawing.Point(329, 116);
            this.labelE_2.Name = "labelE_2";
            this.labelE_2.Size = new System.Drawing.Size(131, 36);
            this.labelE_2.TabIndex = 1;
            this.labelE_2.Text = "Equipo_2";
            // 
            // gol1
            // 
            this.gol1.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gol1.Location = new System.Drawing.Point(216, 163);
            this.gol1.Name = "gol1";
            this.gol1.Size = new System.Drawing.Size(52, 58);
            this.gol1.TabIndex = 2;
            this.gol1.Text = "0";
            // 
            // gol2
            // 
            this.gol2.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gol2.Location = new System.Drawing.Point(363, 163);
            this.gol2.Name = "gol2";
            this.gol2.Size = new System.Drawing.Size(56, 58);
            this.gol2.TabIndex = 3;
            this.gol2.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(286, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 36);
            this.label5.TabIndex = 4;
            this.label5.Text = "__";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Location = new System.Drawing.Point(199, 224);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(208, 132);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            // 
            // c
            // 
            this.c.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c.Location = new System.Drawing.Point(381, 9);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(31, 57);
            this.c.TabIndex = 17;
            this.c.Text = ":";
            // 
            // label_milisegundos
            // 
            this.label_milisegundos.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_milisegundos.Location = new System.Drawing.Point(402, 15);
            this.label_milisegundos.Name = "label_milisegundos";
            this.label_milisegundos.Size = new System.Drawing.Size(78, 57);
            this.label_milisegundos.TabIndex = 16;
            this.label_milisegundos.Text = "59";
            // 
            // label_segundos
            // 
            this.label_segundos.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_segundos.Location = new System.Drawing.Point(318, 15);
            this.label_segundos.Name = "label_segundos";
            this.label_segundos.Size = new System.Drawing.Size(78, 57);
            this.label_segundos.TabIndex = 15;
            // 
            // b
            // 
            this.b.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b.Location = new System.Drawing.Point(293, 9);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(31, 57);
            this.b.TabIndex = 14;
            this.b.Text = ":";
            // 
            // label_minutos
            // 
            this.label_minutos.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_minutos.Location = new System.Drawing.Point(227, 15);
            this.label_minutos.Name = "label_minutos";
            this.label_minutos.Size = new System.Drawing.Size(85, 60);
            this.label_minutos.TabIndex = 13;
            // 
            // a
            // 
            this.a.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a.Location = new System.Drawing.Point(201, 9);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(34, 63);
            this.a.TabIndex = 12;
            this.a.Text = ":";
            // 
            // label_hora
            // 
            this.label_hora.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_hora.Location = new System.Drawing.Point(124, 15);
            this.label_hora.Name = "label_hora";
            this.label_hora.Size = new System.Drawing.Size(83, 57);
            this.label_hora.TabIndex = 11;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // listBox1
            // 
            this.listBox1.Enabled = false;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(38, 116);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(99, 95);
            this.listBox1.TabIndex = 18;
            // 
            // listBox2
            // 
            this.listBox2.Enabled = false;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(481, 116);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(103, 95);
            this.listBox2.TabIndex = 19;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.BalloonTipClicked += new System.EventHandler(this.notifyIcon1_BalloonTipClicked);
            // 
            // Publico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 425);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.c);
            this.Controls.Add(this.label_milisegundos);
            this.Controls.Add(this.label_segundos);
            this.Controls.Add(this.b);
            this.Controls.Add(this.label_minutos);
            this.Controls.Add(this.a);
            this.Controls.Add(this.label_hora);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gol2);
            this.Controls.Add(this.gol1);
            this.Controls.Add(this.labelE_2);
            this.Controls.Add(this.labelE1);
            this.Name = "Publico";
            this.Text = "Publico";
            this.Load += new System.EventHandler(this.Publico_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelE1;
        private System.Windows.Forms.Label labelE_2;
        private System.Windows.Forms.Label gol1;
        private System.Windows.Forms.Label gol2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label c;
        private System.Windows.Forms.Label label_milisegundos;
        private System.Windows.Forms.Label label_segundos;
        private System.Windows.Forms.Label b;
        private System.Windows.Forms.Label label_minutos;
        private System.Windows.Forms.Label a;
        private System.Windows.Forms.Label label_hora;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
    }
}