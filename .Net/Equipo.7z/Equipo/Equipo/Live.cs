﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using DAL;
using Entities;


namespace Equipo
{
    public partial class Live : Form
    {
                
        public Live()
        {
            InitializeComponent();
        }

        DateTime par = DateTime.Now;
        TimeSpan fecha;
        int milise;
        int seg;
        int min;
        int ho;
        DateTime fechaAh;
        int idPartido;
        private void Live_Load(object sender, EventArgs e)
        {
            
            timer1.Start();
            label1.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
            button1.Visible = false;
            listBox1.Visible = false;
            listBox2.Visible = false;

            

            var part = new DAL.PartidoDAL().VerTodo();
            foreach (Partido p in part)
            {
                fechaAh = p.fechaPartido;
                fecha = fechaAh - par;
                double hora1 = fecha.TotalHours;
                if (hora1 > 0 && hora1 <= 2)
                {
                    milise = fecha.Milliseconds;
                    seg = fecha.Seconds;
                    min = fecha.Minutes;
                    ho = fecha.Hours;
                }
            }

            ////label_milisegundos.Text = milise.ToString();
            label_segundos.Text = seg.ToString();
            label_minutos.Text = min.ToString();
            label_hora.Text = ho.ToString();
        }

        Boolean traer = false;
        private void timer1_Tick(object sender, EventArgs e)
        {

            if (label_hora.Text == Convert.ToString(0))
            {
                label_hora.Visible = false;
                a.Visible = false;
            }

            if (label_hora.Text == Convert.ToString(0) && label_minutos.Text == Convert.ToString(0))
            {
                label_hora.Visible = false;
                a.Visible = false;
                label_minutos.Visible = false;
                b.Visible = false;
            }

            if (label_minutos.Text == Convert.ToString(0) && label_segundos.Text == Convert.ToString(0))
            {
                
                label_minutos.Visible = false;
                b.Visible = false;
                label_segundos.Visible = false;
                c.Visible = false;
            }

            timer1.Interval = 10;                        
            int milesima, segundo, minuto, hora;
            milesima = Convert.ToInt32(label_milisegundos.Text);            
            milesima -= 1;
            label_milisegundos.Text = milesima.ToString();

            if (milesima == 0)
            {
                segundo = Convert.ToInt32(label_segundos.Text);
                if (label_segundos.Visible == false)
                {
                    label_milisegundos.Visible = false;
                    traer = true;
                    timer1.Stop();
                }
                segundo -= 1;
                label_segundos.Text = segundo.ToString();
                label_milisegundos.Text = "59";

                if (segundo == 0)
                {
                    minuto = Convert.ToInt32(label_minutos.Text);
                    if (label_minutos.Visible == false)
                    {
                        label_segundos.Visible = false;
                        c.Visible = false;
                    }
                    minuto -= 1;
                    label_minutos.Text = minuto.ToString();
                    label_segundos.Text = "59";

                    if (minuto == 0)
                    {
                        hora = Convert.ToInt32(label_hora.Text);
                        if (hora == 0)
                        {
                            label_minutos.Visible = false;
                            b.Visible = false;
                        }
                        hora -= 1;
                        label_hora.Text = hora.ToString();
                        label_minutos.Text = "59";
                        if (hora == 0)
                        {
                            label_hora.Visible = false;
                            a.Visible = false;
                        }


                    }
                }
            }
            
            if (traer == true)
            {
                label1.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                button1.Visible = true;
                listBox1.Visible = true;
                listBox2.Visible = true;

                var pe = new DAL.PartidoDAL().BuscarPorFechaPartido(fechaAh);
                string nomL = pe.NombreLocal;
                string nomV = pe.NombreVisita;
                idPartido = pe.idPartido;
                int golL = pe.golesLocal;
                int golV = pe.golesVisita;

                label6.Text = nomL;
                label7.Text = nomV;

                textBox1.Text = golL.ToString();
                textBox2.Text = golV.ToString();

                var contr = new DAL.ContratoDAL().BuscarPorNombreEquipo(label6.Text);                                                
                string nombreEquipo = contr.nombreEquipo;                                            
                var vertodo = new DAL.FicharJugadorDAL().VerTodo();
                foreach (FichaContrato f in vertodo)
                {
                    string nombre = f.nombreEquipo;
                    if (nombreEquipo == nombre)
                    {

                        listBox1.DataSource = new DAL.FicharJugadorDAL().BuscarPorNombre2(nombreEquipo);
                        //MessageBox.Show("UNOOO");
                    }
                }

                var contra = new DAL.ContratoDAL().BuscarPorNombreEquipo(label7.Text);
                string nombreEquipos = contra.nombreEquipo;
                var vertodos = new DAL.FicharJugadorDAL().VerTodo();
                foreach (FichaContrato f in vertodos)
                {
                    string nombres = f.nombreEquipo;
                    if (nombreEquipos == nombres)
                    {

                        listBox2.DataSource = new DAL.FicharJugadorDAL().BuscarPorNombre2(nombreEquipos);
                        //MessageBox.Show("UNOOO");
                    }
                }




                //listBox1.DataSource = new DAL.JugadorDAL().VerTodo();
                //listBox1.ValueMember = "Nombre";

                //listBox2.DataSource = new DAL.JugadorDAL().VerTodo();
                //listBox2.ValueMember = "Nombre";

                
            }               
                        
                    
                
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int actua = new DAL.PartidoDAL().actualizarGoles(int.Parse(textBox1.Text), int.Parse(textBox2.Text), label6.Text, label7.Text);
            if (actua == 1)
            {
                var a = new DAL.JugadorDAL().BuscarPorNombre(listBox1.Text);
                int id = a.id;

                MessageBox.Show("Se actualizo el partido");
                EventoPartido ev = new EventoPartido(id,idPartido);
                ev.Show();
            }
            else
            { 
            
            }
        }                       
    }
}

    

