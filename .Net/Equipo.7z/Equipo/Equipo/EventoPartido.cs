﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Equipo
{
    public partial class EventoPartido : Form
    {
        public EventoPartido(int idJugador,int idPartido)
        {
            InitializeComponent();
            this.idJ = idJugador;
            this.idPa = idPartido;
            

        }

        int idJ;
        int idPa;
        

        private void EventoPartido_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Entities.EventoPartido eve = new Entities.EventoPartido
                {
                    idJugador = idJ,
                    idPartido = idPa,
                    fechaEvento = DateTime.Now,
                    nota = textBox1.Text
                };
                int r = new DAL.EventoPartidoDAL().Insertar(eve);
                MessageBox.Show("Evento agregado");
            }
            catch (Exception)
            {
                MessageBox.Show("ya ha sido agregado");
            }
        }
    }
}
