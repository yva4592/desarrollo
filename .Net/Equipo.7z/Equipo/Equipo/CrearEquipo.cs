﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using Entities;
using DAL.DsEquipoTableAdapters;

namespace Equipo
{
    public partial class CrearEquipo : Form
    {
        public CrearEquipo()
        {
            InitializeComponent();
        }

        private void BtnCrear_Click(object sender, EventArgs e)
        {
            string nombre;
            DateTime fechacreacion;
            string localidad;

            Boolean insertar = true;

            var a = new DAL.EquipoDAL().VerTodo();
            foreach (Entities.Equipo eq in a)
            {
                
                nombre = eq.nombreEquipo;
                fechacreacion = eq.fechaCreacion;
                localidad = eq.localidad;

                if (textBox1.Text == nombre)
                {
                    insertar = false;
                    MessageBox.Show("Ya existe el Equipo ");
                }                

            }

            

            if (insertar == true)
            {

                 Entities.Equipo eq = new Entities.Equipo()
                {
                    nombreEquipo = textBox1.Text,
                    fechaCreacion = dateTimePicker1.Value,
                    localidad = textBox3.Text

                };

                int r = new DAL.EquipoDAL().Insertar(eq);
                if (r == 1)
                    MessageBox.Show("Creado nuevo Equipo");
                else
                    MessageBox.Show("Ya existe el Equipo");

            }
            


        }

        private void CrearEquipo_Load(object sender, EventArgs e)
        {

        }
    }
}
