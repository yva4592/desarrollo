﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Entities;
using DAL;


namespace Equipo
{
    public partial class PagoEquipo : Form
    {
        public PagoEquipo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            var contr = new DAL.ContratoDAL().BuscarPorNombreEquipo(comboBox1.Text);                        
            try
            {
                string nombreEquipo = contr.nombreEquipo;                            
                int total = 0;
                var vertodo = new DAL.FicharJugadorDAL().VerTodo();
                foreach (FichaContrato f in vertodo)
                {
                    string nombre = f.nombreEquipo;
                    if (nombreEquipo == nombre)
                    {

                        dataGridView1.DataSource = new DAL.FicharJugadorDAL().BuscarPorNombre(nombreEquipo);
                        //MessageBox.Show("UNOOO");
                    }
                }


                var v = new DAL.FicharJugadorDAL().BuscarPorNombre(nombreEquipo);
                foreach (FichaContrato fi in v)
                {
                    int pago = fi.pagoMensual;
                    total = total + pago;
                }

                label3.Text = Convert.ToString(total);

            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Equipo no tiene Jugadores");
            } 
        }

        private void PagoEquipo_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource =  new DAL.EquipoDAL().VerTodo();
            comboBox1.ValueMember = "nombreEquipo";
        }
    }
}
