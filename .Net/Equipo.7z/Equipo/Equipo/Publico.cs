﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using Entities;

namespace Equipo
{
    public partial class Publico : Form
    {
        public Publico()
        {
            InitializeComponent();
        }

        DateTime par = DateTime.Now;
        TimeSpan fecha;
        int milise;
        int seg;
        int min;
        int ho;
        DateTime fechaAh;
        int idPartido;

        private void Publico_Load(object sender, EventArgs e)
        {
            timer1.Start();
            richTextBox1.Visible = false;
            labelE1.Visible = true;
            labelE_2.Visible = true;
            gol1.Visible = false;
            gol2.Visible = false;

            listBox1.Visible = true;
            listBox2.Visible = true;

            var part = new DAL.PartidoDAL().VerTodo();
            foreach (Partido p in part)
            {
                fechaAh = p.fechaPartido;
                fecha = fechaAh - par;
                double hora1 = fecha.TotalHours;
                if (hora1 > 0 && hora1 <= 2)
                {
                    milise = fecha.Milliseconds;
                    seg = fecha.Seconds;
                    min = fecha.Minutes;
                    ho = fecha.Hours;
                }
            }

            ////label_milisegundos.Text = milise.ToString();
            label_segundos.Text = seg.ToString();
            label_minutos.Text = min.ToString();
            label_hora.Text = ho.ToString();

            
        }

        Boolean traer = false;
        private void timer1_Tick(object sender, EventArgs e)
        {

            if (label_hora.Text == Convert.ToString(0))
            {
                label_hora.Visible = false;
                a.Visible = false;
            }
            timer1.Interval = 10;
            int milesima, segundo, minuto, hora;
            milesima = Convert.ToInt32(label_milisegundos.Text);
            milesima -= 1;
            label_milisegundos.Text = milesima.ToString();

            if (milesima == 0)
            {
                segundo = Convert.ToInt32(label_segundos.Text);
                if (label_segundos.Visible == false)
                {
                    label_milisegundos.Visible = false;
                    traer = true;
                    timer1.Stop();
                }
                segundo -= 1;
                label_segundos.Text = segundo.ToString();
                label_milisegundos.Text = "59";

                if (segundo == 0)
                {
                    minuto = Convert.ToInt32(label_minutos.Text);
                    if (label_minutos.Visible == false)
                    {
                        label_segundos.Visible = false;
                        c.Visible = false;
                    }
                    minuto -= 1;
                    label_minutos.Text = minuto.ToString();
                    label_segundos.Text = "59";

                    if (minuto == 0)
                    {
                        hora = Convert.ToInt32(label_hora.Text);
                        if (hora == 0)
                        {
                            label_minutos.Visible = false;
                            b.Visible = false;
                        }
                        hora -= 1;
                        label_hora.Text = hora.ToString();
                        label_minutos.Text = "59";
                        if (hora == 0)
                        {
                            label_hora.Visible = false;
                            a.Visible = false;
                        }


                    }
                }
            }

            if (traer == true)
            {
                labelE1.Visible = true;
                labelE_2.Visible = true;
                gol1.Visible = true;
                gol2.Visible = true;
                
                listBox1.Visible = true;
                listBox2.Visible = true;

                var pe = new DAL.PartidoDAL().BuscarPorFechaPartido(fechaAh);
                string nomL = pe.NombreLocal;
                string nomV = pe.NombreVisita;
                idPartido = pe.idPartido;
                int golL = pe.golesLocal;
                int golV = pe.golesVisita;

                labelE1.Text = nomL;
                labelE_2.Text = nomV;

                gol1.Text = golL.ToString();
                gol2.Text = golV.ToString();

                listBox1.DataSource = new DAL.JugadorDAL().VerTodo();
                listBox1.ValueMember = "Nombre";

                listBox2.DataSource = new DAL.JugadorDAL().VerTodo();
                listBox2.ValueMember = "Nombre";


            }


        }

        private void timer2_Tick(object sender, EventArgs e)
        {
          
        }

        private void notifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {

        }

        

        
    }
}
