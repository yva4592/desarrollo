﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Entities;
using DAL.DsEquipoTableAdapters;
using DAL;


namespace Equipo
{
    public partial class CrearTorneo : Form
    {
        public CrearTorneo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime FC = dateTimePicker1.Value;
            DateTime FI = dateTimePicker2.Value;
            DateTime FT = dateTimePicker3.Value;
            Boolean insertar=false; 
            DateTime fi;
            DateTime ft;
            if (FI < FT)
            {
                                    
                var a = new DAL.TorneoDAL().VerTodo();
                insertar = true;
                foreach (Torneo to in a)
                {
                    fi = to.fechaInicio;
                    ft = to.fechaTermino;
                    
                    if ((FI < fi && FT < fi) || (FI > ft && FT > ft))
                    {
                        insertar =  true;
                    
                    }
                    else
                    {
                        insertar = false;
                        MessageBox.Show("Ya existe un torneo entre esas fechas");
                    }                    
                }
            }
            else
            {
                MessageBox.Show("fecha inicio debe ser menor que la fecha termino");
            }


            if (insertar == true)
            {
                Entities.Torneo user = new Entities.Torneo
                {
                    fechaCreacion = FC,
                    fechaInicio = FI,
                    fechaTermino = FT

                    //Edad = int.Parse(txtTitulo.Text),
                    //Nick = txtId.Text,
                    //Fecha = fecha
                };

                int ins = new DAL.TorneoDAL().Insertar(user);
                if (ins == 1)
                    MessageBox.Show("agregado");
                else
                    MessageBox.Show("ya existe");
            }
            
        }

        private void CrearTorneo_Load(object sender, EventArgs e)
        {

        }

        
    }
}
