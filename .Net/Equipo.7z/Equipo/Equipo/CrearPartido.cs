﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using Entities;


namespace Equipo
{
    public partial class CrearPartido : Form
    {
        
        public CrearPartido()
        {
            InitializeComponent();
        }

        private void CrearPartido_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = new DAL.EquipoDAL().VerTodo();
            comboBox1.ValueMember = "nombreEquipo";                           
            comboBox2.DataSource = new DAL.EquipoDAL().VerTodo();
            comboBox2.ValueMember = "nombreEquipo";
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                label11.Text = "";
                label12.Text = "";
                MessageBox.Show("debe ingresar una fecha ejemplo 10/12/2012 08:30");
                
            }
            else
            {
                Boolean fechaV = true;
                Boolean insertar = true;
                if (comboBox1.Text != comboBox2.Text)
                {
                    insertar = true;

                    int cantJugadores = 0;
                    var ver = new DAL.ContratoDAL().VerTodo();
                    foreach (Contrato c in ver)
                    {
                        string nombEq = c.nombreEquipo;
                        if (nombEq == comboBox1.Text)
                        {
                            cantJugadores++;
                        }
                        
                    }
                    if (cantJugadores < 11)
                    {
                        label11.Text = "Equipo " + comboBox1.Text + " no tiene 11 Jugadores";
                        //MessageBox.Show("Equipo " + comboBox1.Text + " no tiene 11 Jugadores");
                        insertar = false;
                        fechaV = false;
                    }
                    else
                    {
                        label11.Text = "";
                    }


                    int cantJugadores1 = 0;
                    var ver1 = new DAL.ContratoDAL().VerTodo();
                    foreach (Contrato ce in ver1)
                    {
                        string nombEqui = ce.nombreEquipo;
                        if (nombEqui == comboBox2.Text)
                        {
                            cantJugadores1++;
                        }
                    }
                    if (cantJugadores1 < 11)
                    {
                        label12.Text = "Equipo " + comboBox2.Text + " no tiene 11 Jugadores";
                        //MessageBox.Show("Equipo " + comboBox2.Text + " no tiene 11 Jugadores");
                        insertar = false;
                        fechaV = false;
                    }
                    else
                    {
                        label12.Text = "";
                    }
                }
                else
                {
                    label11.Text = "";
                    label12.Text = "";
                    MessageBox.Show("Error de Seleccion de Equipos");
                    insertar = false;
                    fechaV = false;

                }


                if (fechaV == true)
                {
                    DateTime fechaI = DateTime.Parse(textBox1.Text);
                    TimeSpan dif;
                    var todo = new DAL.PartidoDAL().VerTodo();
                    foreach (Partido p in todo)
                    {
                        string eqL = p.NombreLocal;
                        string eqV = p.NombreVisita;
                        DateTime fecha = p.fechaPartido;

                        if ((eqL != comboBox1.Text && eqV != comboBox2.Text))
                        {
                            dif = fechaI - fecha;
                            double hora = dif.TotalHours;
                            if (hora >= 2)
                            {
                                insertar = true;
                            }
                            else
                            {
                                label11.Text = "";
                                label12.Text = "";
                                insertar = false;
                                MessageBox.Show("Son 2 horas de diferencia!!!");
                                
                            }
                        }
                        else
                        {
                            label11.Text = "";
                            label12.Text = "";
                            insertar = false;
                            MessageBox.Show("Equipos ya tienen partido");
                            
                        }
                    }


                    if (insertar == true)
                    {

                        Entities.Partido partido = new Entities.Partido()
                        {
                            idTorneo = 1,
                            NombreLocal = comboBox1.Text,
                            NombreVisita = comboBox2.Text,
                            golesLocal = 0,
                            golesVisita = 0,
                            fechaPartido = fechaI
                        };

                        int par = new DAL.PartidoDAL().Insertar(partido);
                        if (par == 1)
                        {
                            label11.Text = "";
                            label12.Text = "";
                            MessageBox.Show("Partido Generado");
                            //timer1.Start();
                        }
                        else
                        {
                            label11.Text = "";
                            label12.Text = "";
                            MessageBox.Show("No se genero el partido");

                        }
                    }
                }

            }
        }

        

        
        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    timer1.Interval = 10;
        //    int  milesima ,segundo, minuto,hora;

        //    milesima = Convert.ToInt32(label7.Text);
        //    milesima += 1;
        //    label7.Text = milesima.ToString();
        //    if (milesima == 60)
        //    {
        //        segundo = Convert.ToInt32(label5.Text);
        //        segundo += 1;
        //        label5.Text = segundo.ToString();
        //        label7.Text = "00";
        //        if (segundo == 60)
        //        {
        //            minuto = Convert.ToInt32(label3.Text);
        //            minuto += 1;
        //            label3.Text = minuto.ToString();
        //            label5.Text = "00";
        //            if (minuto == 60)
        //            {
        //                hora = Convert.ToInt32(label6.Text);
        //                hora += 1;
        //                label6.Text = hora.ToString();
        //                label5.Text = "00";
        //                if (hora == 1 && minuto == 45)
        //                {
        //                    MessageBox.Show("Termino el Partido");
        //                }
        //                if (hora == 2)
        //                {
        //                    timer1.Stop();
        //                    MessageBox.Show("Puede comensar otro Partido");
                            
        //                }
        //            }
        //        }
                
        //    }
            
        //}

        

            //public int Cronometro()
            //{
            //    int a;
            //    Boolean verdad = true;
            //    for (a = 0; verdad == true; a++)
            //    {
            //        if (a == 7200)
            //        {
            //            verdad = false;
            //        }
            //        else
            //        {
            //            return a;
            //        }
            //    }
            //    return a;
            //}
        }                
    }

