﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace Equipo
{
    public partial class CrearContrato : Form
    {
        public CrearContrato()
        {
            InitializeComponent();
        }

        private void BtnCrearContrato_Click(object sender, EventArgs e)
        {

            var var = new DAL.JugadorDAL().BuscarPorNombre(comboBox1.Text);
            int id = var.id;
            Boolean insertar = true;            
            int idjugador = 0;
            string nombreEquipo = "";
            var a = new DAL.ContratoDAL().VerTodo();        
            foreach (Contrato to in a)
            {
                idjugador = to.idJugador;
                nombreEquipo = to.nombreEquipo;

                if ((id == idjugador) )
                {
                    
                    insertar = false;
                    MessageBox.Show("Contrato ya existe o Jugador ya tiene equipo");
                }
            }

                        
            if (insertar == true)
            {
                Entities.Contrato user = new Entities.Contrato
                {
                    idJugador = id,
                    nombreEquipo = comboBox2.Text                    
                    
                };


                try
                {
                    int ins = new DAL.ContratoDAL().Insertar(user);                                    
                    int inse = new DAL.FicharJugadorDAL().Insertar(id, comboBox2.Text, int.Parse(textBox1.Text));
                    if (inse == 1 && ins == 1)
                    {
                        dataGridView2.DataSource = new ContratoDAL().VerTodo();
                        dataGridView1.DataSource = new FicharJugadorDAL().VerTodo();
                    }
                    else
                    {
                        MessageBox.Show("ya existe");
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Colocar el sueldo del jUgador");
                }
               
            }
        }

        private void CrearContrato_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = new JugadorDAL().VerTodo();
            //comboBox1.DisplayMember = "id";
            comboBox1.ValueMember = "Nombre";

            comboBox2.DataSource = new EquipoDAL().VerTodo();
            comboBox2.DisplayMember = "nombreEquipo";

            dataGridView1.DataSource = new FicharJugadorDAL().VerTodo();
            dataGridView2.DataSource = new ContratoDAL().VerTodo();
        }

        private void BtnTraspaso_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "")
            {
                MessageBox.Show("el pago es obigatorio");
            }
            else
            {
                try
                {
                    var s = new DAL.FicharJugadorDAL().ActualizarContrato(int.Parse(comboBox1.Text), comboBox2.Text, int.Parse(textBox1.Text));


                    MessageBox.Show("yeah");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }
            }


            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar) < 48 && e.KeyChar != 8) || e.KeyChar > 57)
            {
                MessageBox.Show("Solo Nùmeros");
                e.Handled = true;
            }
        }

        
    }
}
