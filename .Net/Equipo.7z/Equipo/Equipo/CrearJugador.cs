﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace Equipo
{
    public partial class CrearJugador : Form
    {
        public CrearJugador()
        {
            InitializeComponent();
        }

        private void BtnCrear_Click(object sender, EventArgs e)
        {

            int rut;
            string nombre;
            string apellido;

            Boolean insertar = true;

            var a = new DAL.JugadorDAL().VerTodo();
            foreach (Jugador ju in a)
            {

                rut = ju.rut;
                nombre = ju.Nombre;
                apellido = ju.apellido;

                if (int.Parse(textBox2.Text) == rut)
                {
                  
                    insertar = false;
                    MessageBox.Show("Ya existe el Jugador");
                }
            }

            
            if (insertar == true)
            {

                Entities.Jugador eq = new Entities.Jugador()
                {
                    rut = int.Parse(textBox2.Text),
                    Nombre = textBox3.Text,
                    apellido = textBox4.Text

                };

                int r = new DAL.JugadorDAL().Insertar(eq);
                if (r == 1)
                    MessageBox.Show("Agregado");
                else
                    MessageBox.Show("no agregado");

            }

        }



        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar) < 48 && e.KeyChar != 8) || e.KeyChar > 57)
            {
                MessageBox.Show("Solo Nùmeros");
                e.Handled = true;
            }
        }

        

        
    }
}
