﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Equipo
{
    public partial class FichaJugador : Form
    {
        public FichaJugador()
        {
            InitializeComponent();
        }

        private void FichaJugador_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = new DAL.JugadorDAL().VerTodo();
            comboBox1.ValueMember = "rut";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            var ver = new DAL.JugadorDAL().BuscarPorRut(int.Parse(comboBox1.Text));
            int idJugador = ver.id;
            string Nombre = ver.Nombre;
            string Apellido = ver.apellido;

            var da = new DAL.ContratoDAL().BuscarPorId(idJugador);
            try
            {
                string nombreEquipo = da.nombreEquipo;
                 
                label1.Text = nombreEquipo;
                label3.Text = Nombre;
                label4.Text = Apellido;
            }

            catch (NullReferenceException)
            {
                MessageBox.Show("Jugador no Tiene Equipo");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var ver = new DAL.JugadorDAL().BuscarPorRut(int.Parse(comboBox1.Text));
            int idJugador = ver.id;

            dataGridView1.DataSource = new DAL.ContratoDAL().BuscarPorId2(idJugador);
        }


    }
}
