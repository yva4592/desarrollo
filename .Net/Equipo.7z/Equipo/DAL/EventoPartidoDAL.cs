﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace DAL
{
    public class EventoPartidoDAL
    {

        EventoPartidoTableAdapter discoTb;        

         public EventoPartidoDAL()
         {
             discoTb = new EventoPartidoTableAdapter();
         }

         //public int Eliminar(int original_idJugador)
         //{
         //    try
         //    {
         //        return discoTb.EliminarContrato(original_idJugador);
         //    }
         //    catch (System.Data.SqlClient.SqlException ex)
         //    {
         //        if (ex.Number == 2627)
         //        {
         //            return -1;
         //        }
         //        return -99;  
         //    }
         //}

         public int Insertar(EventoPartido disco)
         {
             try
             {
                 return discoTb.Insert(disco.idJugador,disco.idPartido,disco.fechaEvento,disco.nota);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;
             }
         }

         //public int Actualizar(int idJugador,string nombreEquipo,int Original_idJugador,string Original_nombreEquipo)
         //{
         //    try
         //    {
         //        return discoTb.actualizar(idJugador,nombreEquipo,Original_idJugador,Original_nombreEquipo);
         //    }
         //    catch (System.Data.SqlClient.SqlException ex)
         //    {
         //        if (ex.Number == 2627)
         //        {
         //            return -1;
         //        }
         //        return -99;
         //    }
         //}

         //public List<Contrato> VerTodo()
         //{
         //    var tabla = discoTb.GetData();
         //    return ALista(tabla);
         //}

         //private List<Contrato> ALista(DsEquipo.ContratoDataTable tabla)
         //{
         //    List<Contrato> discos = new List<Contrato>();
         //    foreach (System.Data.DataRow fila in tabla.Rows)
         //    {
         //        discos.Add(new Contrato
         //        {
         //           idJugador = int.Parse(fila[0].ToString()),
         //           nombreEquipo = fila[1].ToString()
                    
         //        });
         //    }
         //    return discos;
         //}

         //public List<Torneo> verPorFIyFT(DateTime fi, DateTime ft)
         //{
         //    var a = discoTb.verPorFIandFT(fi, ft);
         //    return verFIyFT(a);
         //}

         //private List<Torneo> verFIyFT(DsEquipo.TorneoDataTable tabla)
         //{
         //    List<Torneo> discos = new List<Torneo>();
         //    foreach (System.Data.DataRow fila in tabla.Rows)
         //    {
         //        discos.Add(new Torneo
         //        {
         //            idTorneo = int.Parse(fila[0].ToString()),
         //            fechaCreacion = DateTime.Parse(fila[1].ToString()),
         //            fechaInicio = DateTime.Parse(fila[2].ToString()),
         //            fechaTermino = DateTime.Parse(fila[3].ToString())
         //        });
         //    }
         //    return discos;
         //}





         //public Contrato BuscarPorId(int id)
         //{
         //    var tabla = discoTb.verPorIdJugador(id);
         //    return ALista(tabla).FirstOrDefault();
         //    //.FirstOrDefault();
         //}

         //public List<Contrato> BuscarPorId2(int id)
         //{
         //    var tabla = discoTb.verPorIdJugador(id);
         //    return ALista(tabla);
         //    //.FirstOrDefault();
         //}

         //public Contrato BuscarPorNombreEquipo(string nombreEquipo)
         //{
         //    var tabla = discoTb.verPorNombreEquipo(nombreEquipo);
         //    return ALista(tabla).FirstOrDefault();
         //    //.FirstOrDefault();
         //}

         //public List<Contrato> BuscarPorNombreEquipo2(string nombreEquipo)
         //{
         //    var tabla = discoTb.verPorNombreEquipo(nombreEquipo);
         //    return ALista(tabla);
         //    //.FirstOrDefault();
         //}




         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}
    }
}
