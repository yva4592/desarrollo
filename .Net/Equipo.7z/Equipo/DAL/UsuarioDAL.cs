﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using Entities;

namespace DAL
{
    public class UsuarioDAL
    {
        UsuarioTableAdapter discoTb;        

         public UsuarioDAL()
         {
             discoTb = new UsuarioTableAdapter();
         }

         public int Insertar(Usuario disco)
         {
             try
             {
                 return discoTb.Insert(disco.tipo);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;                 
             }                
         }

         public List<Usuario> VerTodo()
         {
             var tabla = discoTb.GetData();
             return ALista(tabla);
         }

         private List<Usuario> ALista(DsEquipo.UsuarioDataTable tabla)
         {
             List<Usuario> discos = new List<Usuario>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Usuario
                 {
                    idUsuario = int.Parse(fila[0].ToString()),
                    tipo = fila[1].ToString()                                       
                 });
             }
             return discos;
         }

         public List<Usuario> verPorIDyTipo(int id,string tipo)
         {
            var a = discoTb.verificarPorIDyTipo(id, tipo);
            return verIDyTipo(a);
         }

         private List<Usuario> verIDyTipo(DsEquipo.UsuarioDataTable tabla)
         {
             List<Usuario> discos = new List<Usuario>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Usuario
                 {
                     idUsuario = int.Parse(fila[0].ToString()),
                     tipo = fila[1].ToString()
                 });
             }
             return discos;
         }




         //public Usuario BuscarPorId(int id)
         //{
         //    var tabla = discoTb.buscarxid(id);
         //    return ALista(tabla).FirstOrDefault();
         //    //.FirstOrDefault();
         //}




         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}

    }
}
