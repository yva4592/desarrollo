﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace DAL
{
    public class TorneoDAL
    {
        TorneoTableAdapter discoTb;        

         public TorneoDAL()
         {
             discoTb = new TorneoTableAdapter();
         }

         public int Insertar(Torneo disco)
         {
             try
             {
                 return discoTb.Insert(disco.fechaCreacion,disco.fechaInicio,disco.fechaTermino);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;                 
             }                
         }

         public List<Torneo> VerTodo()
         {
             var tabla = discoTb.GetData();
             return ALista(tabla);
         }

         private List<Torneo> ALista(DsEquipo.TorneoDataTable tabla)
         {
             List<Torneo> discos = new List<Torneo>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Torneo
                 {
                    fechaCreacion = DateTime.Parse(fila[1].ToString()),
                    fechaInicio = DateTime.Parse(fila[2].ToString()),
                    fechaTermino = DateTime.Parse(fila[3].ToString())                   
                 });
             }
             return discos;
         }

         public List<Torneo> verPorFIyFT(DateTime fi, DateTime ft)
         {
             var a = discoTb.verPorFIandFT(fi, ft);
             return verFIyFT(a);
         }

         private List<Torneo> verFIyFT(DsEquipo.TorneoDataTable tabla)
         {
             List<Torneo> discos = new List<Torneo>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Torneo
                 {
                     idTorneo = int.Parse(fila[0].ToString()),
                     fechaCreacion = DateTime.Parse(fila[1].ToString()),
                     fechaInicio = DateTime.Parse(fila[2].ToString()),
                     fechaTermino = DateTime.Parse(fila[3].ToString())
                 });
             }
             return discos;
         }





         public Torneo BuscarPorIdTorneo(int idTorneo)
         {
             var tabla = discoTb.verPorIdTorneo(idTorneo);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }




         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}
    }
}
