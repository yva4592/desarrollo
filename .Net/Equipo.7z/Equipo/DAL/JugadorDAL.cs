﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace DAL
{
    public class JugadorDAL
    {
        JugadorTableAdapter discoTb;        

         public JugadorDAL()
         {
             discoTb = new JugadorTableAdapter();
         }

         public int Insertar(Jugador disco)
         {
             try
             {
                 return discoTb.Insert(disco.rut,disco.Nombre,disco.apellido);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;                 
             }                
         }

         public List<Jugador> VerTodo() 
         {
             var tabla = discoTb.GetData();
             return ALista(tabla);
         }

         private List<Jugador> ALista(DsEquipo.JugadorDataTable tabla)
         {
             List<Jugador> discos = new List<Jugador>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Jugador
                 {  
                    id = int.Parse(fila[0].ToString()),
                    rut = int.Parse(fila[1].ToString()),
                    Nombre = fila[2].ToString(),
                    apellido = fila[3].ToString()                                       
                 });
             }
             return discos;
         }

         //public List<Usuario> verPorIDyTipo(int id,string tipo)
         //{
         //   var a = discoTb.verificarPorIDyTipo(id, tipo);
         //   return verIDyTipo(a);
         //}

         //private List<Usuario> verIDyTipo(DsEquipo.UsuarioDataTable tabla)
         //{
         //    List<Usuario> discos = new List<Usuario>();
         //    foreach (System.Data.DataRow fila in tabla.Rows)
         //    {
         //        discos.Add(new Usuario
         //        {
         //            idUsuario = int.Parse(fila[0].ToString()),
         //            tipo = fila[1].ToString()
         //        });
         //    }
         //    return discos;
         //}




         public Jugador BuscarPorRut(int rut)
         {
             var tabla = discoTb.verPorRut(rut);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }

         public Jugador BuscarPorNombre(string Nombre)
         {
             var tabla = discoTb.verPorNombre(Nombre);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }

         public Jugador BuscarPorID(int id)
         {
             var tabla = discoTb.VerPorID(id);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }

         public List<Jugador> BuscarPorID2(int id)
         {
             var tabla = discoTb.VerPorID(id);
             return ALista(tabla);
             //.FirstOrDefault();
         }

         public List<Jugador> verPorEquipo(string nombreEquipo)
         {
             var tabla = discoTb.verPorEquipo(nombreEquipo);
             return ALista(tabla);
             //.FirstOrDefault();
         }




         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}
    }
}
