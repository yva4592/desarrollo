﻿namespace DAL {
    
    
    public partial class DsEquipo {
        partial class FichaContratoDataTable
        {
        }
    }
}

namespace DAL.DsEquipoTableAdapters {
    
    
    public partial class PartidoTableAdapter {
    }
}
