﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace DAL
{
    public class FicharJugadorDAL
    {
        FichaContratoTableAdapter discoTb;
        FichaContratoTableAdapter fichaContratoTB;

         public FicharJugadorDAL()
         {
             discoTb = new FichaContratoTableAdapter();
             fichaContratoTB = new FichaContratoTableAdapter();
         }

         public int Actualizar(int? idJugador,string nombreEquipo,int? pagoMensual,int? Original_idJugador,string Original_nombreEquipo,int id)
         {
             try
             {
                 return discoTb.Actualizar20(idJugador, nombreEquipo, pagoMensual, Original_idJugador, Original_nombreEquipo, id);
             }
             catch (System.Data.SqlClient.SqlException ex)
             { 
                if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;           
             }
         }

         public int Insertar(int idJugador, string nombreEquipo,int? pagoMensual)
         {
             try
             {
                 return discoTb.Insert(idJugador,nombreEquipo,pagoMensual);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;                 
             }                
         }

         public List<FichaContrato> VerTodo()
         {
             var tabla = discoTb.GetData();
             return ALista(tabla);
         }

         private List<FichaContrato> ALista(DsEquipo.FichaContratoDataTable tabla)
         {
             List<FichaContrato> discos = new List<FichaContrato>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new FichaContrato
                 {
                     //id = int.Parse(fila[0].ToString()),
                     idJugador = int.Parse(fila[1].ToString()),
                     nombreEquipo = fila[2 ].ToString(),
                     pagoMensual = int.Parse(fila[3].ToString())

                 });
             }
             return discos;
         }

         //public List<Usuario> verPorIDyTipo(int id,string tipo)
         //{
         //   var a = discoTb.verificarPorIDyTipo(id, tipo);
         //   return verIDyTipo(a);
         //}

         //private List<Usuario> verIDyTipo(DsEquipo.UsuarioDataTable tabla)
         //{
         //    List<Usuario> discos = new List<Usuario>();
         //    foreach (System.Data.DataRow fila in tabla.Rows)
         //    {
         //        discos.Add(new Usuario
         //        {
         //            idUsuario = int.Parse(fila[0].ToString()),
         //            tipo = fila[1].ToString()
         //        });
         //    }
         //    return discos;
         //}




         public FichaContrato BuscarPorIdyNombre(int? idJugador,string nombreEquipo)
         {
             var tabla = discoTb.VerPorIdYNombre(idJugador,nombreEquipo);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }

         public List<FichaContrato> BuscarPorNombre(string nombreEquipo)
         {
             var tabla = discoTb.verPorNombreEquipo(nombreEquipo);
             return ALista(tabla);
             //.FirstOrDefault();
         }

         public List<FichaContrato> BuscarPorNombre2(string nombreEquipo)
         {
             
                 var tabla = discoTb.VerPorNombreEquipo2(nombreEquipo);
             
             return ALista(tabla);
             //.FirstOrDefault();
         }




         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}



         public int ActualizarContrato(int idJugador,string nombreEquipo, int pagoMensual)
         {
             try
             {
                 return fichaContratoTB.ActualizarFichaContrato(idJugador, nombreEquipo, pagoMensual);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;
             }
         }
    }
}
