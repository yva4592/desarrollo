﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace DAL
{
    public class PartidoDAL
    {
        PartidoTableAdapter discoTb;        

         public PartidoDAL()
         {
             discoTb = new PartidoTableAdapter();
         }

         public int Insertar(Partido disco)
         {
             try
             {
                 return discoTb.Insert(disco.idTorneo,disco.NombreLocal,disco.NombreVisita,disco.golesLocal,disco.golesVisita,disco.fechaPartido);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;                 
             }                
         }

         public List<Partido> VerTodo() 
         {
             var tabla = discoTb.GetData();
             return ALista(tabla);
         }

         private List<Partido> ALista(DsEquipo.PartidoDataTable tabla)
         {
             List<Partido> discos = new List<Partido>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Partido
                 {
                    idPartido = int.Parse(fila[0].ToString()),
                    idTorneo = int.Parse(fila[1].ToString()),
                    NombreLocal = fila[2].ToString(),
                    NombreVisita = fila[3].ToString(),
                    golesLocal = int.Parse(fila[4].ToString()),
                    golesVisita = int.Parse(fila[5].ToString()),
                    fechaPartido = DateTime.Parse(fila[6].ToString())
                 });
             }
             return discos;
         }

         //public List<Usuario> verPorIDyTipo(int id,string tipo)
         //{
         //   var a = discoTb.verificarPorIDyTipo(id, tipo);
         //   return verIDyTipo(a);
         //}

         //private List<Usuario> verIDyTipo(DsEquipo.UsuarioDataTable tabla)
         //{
         //    List<Usuario> discos = new List<Usuario>();
         //    foreach (System.Data.DataRow fila in tabla.Rows)
         //    {
         //        discos.Add(new Usuario
         //        {
         //            idUsuario = int.Parse(fila[0].ToString()),
         //            tipo = fila[1].ToString()
         //        });
         //    }
         //    return discos;
         //}

         public Partido BuscarPorFechaPartido(DateTime fechaPartido)
         {
             var tabla = discoTb.verPorFechaPartido(fechaPartido);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }


         public Partido BuscarPorNombreEquipo(string nombreEquipo)
         {
             var tabla = discoTb.VerPorNombreEquipo(nombreEquipo);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }


         public Partido BuscarPorEquipos(string EquipoLocal,string EquipoVisita)
         {
             var tabla = discoTb.verPorEquipos(EquipoLocal,EquipoVisita);
             return ALista(tabla).FirstOrDefault();
             //.FirstOrDefault();
         }


         public int actualizarGoles(int golesLocal,int golesVisita,string NombreLocal,string nombreVisita)
         {
             try
             {
                 return discoTb.UpdateGoles(golesLocal, golesVisita, NombreLocal, nombreVisita);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;
             }
         }

         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}
    }
}
