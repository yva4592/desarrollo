﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.DsEquipoTableAdapters;
using DAL;
using Entities;

namespace DAL
{
    public class EquipoDAL
    {
        EquipoTableAdapter discoTb;        

         public EquipoDAL()
         {
             discoTb = new EquipoTableAdapter();
         }

         public int Insertar(Equipo disco)
         {
             try
             {
                 return discoTb.Insert(disco.nombreEquipo,disco.fechaCreacion,disco.localidad);
             }
             catch (System.Data.SqlClient.SqlException ex)
             {
                 if (ex.Number == 2627)
                 {
                     return -1;
                 }
                 return -99;                 
             }                
         }

         public List<Equipo> VerTodo()
         {
             var tabla = discoTb.GetData();
             return ALista(tabla);
         }

         private List<Equipo> ALista(DsEquipo.EquipoDataTable tabla)
         {
             List<Equipo> discos = new List<Equipo>();
             foreach (System.Data.DataRow fila in tabla.Rows)
             {
                 discos.Add(new Equipo
                 {                    
                    nombreEquipo = fila[0].ToString(),
                    fechaCreacion = DateTime.Parse(fila[1].ToString()),
                    localidad = fila[2].ToString()                
                    
                 });
             }
             return discos;
         }

         //public List<Torneo> verPorFIyFT(DateTime fi, DateTime ft)
         //{
         //    var a = discoTb.verPorFIandFT(fi, ft);
         //    return verFIyFT(a);
         //}

         //private List<Torneo> verFIyFT(DsEquipo.TorneoDataTable tabla)
         //{
         //    List<Torneo> discos = new List<Torneo>();
         //    foreach (System.Data.DataRow fila in tabla.Rows)
         //    {
         //        discos.Add(new Torneo
         //        {
         //            idTorneo = int.Parse(fila[0].ToString()),
         //            fechaCreacion = DateTime.Parse(fila[1].ToString()),
         //            fechaInicio = DateTime.Parse(fila[2].ToString()),
         //            fechaTermino = DateTime.Parse(fila[3].ToString())
         //        });
         //    }
         //    return discos;
         //}





         //public Usuario BuscarPorId(int id)
         //{
         //    var tabla = discoTb.buscarxid(id);
         //    return ALista(tabla).FirstOrDefault();
         //    //.FirstOrDefault();
         //}




         //public void Dispose()
         //{
         //   // throw new NotImplementedException();
         //}
    }
}
